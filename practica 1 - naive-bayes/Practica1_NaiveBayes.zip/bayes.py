from Prediction import Prediction
from PreditionCollection import PreditionCollection
from NaiveBayes import NaiveBayes
from NaiveBayesDiscreto import NaiveBayesDiscreto
from NaiveBayesContinuo import NaiveBayesContinuo